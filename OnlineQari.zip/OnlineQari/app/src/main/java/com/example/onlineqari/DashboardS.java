package com.example.onlineqari;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DashboardS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_s);
    }
}
